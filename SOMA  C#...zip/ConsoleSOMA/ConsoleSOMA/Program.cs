﻿

using System;

namespace MyApplication
{
    class Program 
    {
        public static int K { get; private set; }

        static void Main(string[] args)
        {
            int i = 13, soma = 0, k = 0;

            while (k < i)  
            {
                k = k + 1;
                soma = soma + K;
            }

            Console.WriteLine(soma);
            i++;
        }
    }
}

